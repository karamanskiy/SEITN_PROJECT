<?php

// include('data.php');
require 'phpmailer/PHPMailerAutoload.php';
// include('ga_utils.php');

$crm_log = 'Добавление в CRM... ' . date('Y.m.d H:i:s') . "\n\n";

// replace your_mail@your_domain.com with your E-mail address:
$my_email="karamanskyi@gmail.com";
$my_email_to = "karamanskyi@gmail.com";


// change the text below for your Auto-Reply message:
$autoreply_subject = "Заявка";
$autoreply_message = "Спасибо за заявку! Мы свяжемся с вами" . "\n\n" .
				     "С уважением, Строй Эксперт Надзор";

// request data on form submit
$sName = trim($_REQUEST["name"]);
$sPhone = trim($_REQUEST["tel"]);
$sComfortTime = trim($_REQUEST["time"]);
$sComment = trim($_REQUEST["comment"]);
$sFile = trim($_REQUEST["from_file"]);

$s_usluga = trim($_REQUEST["usluga"]);
$s_square = trim($_REQUEST["ploshcha"]);
$s_etaji = trim($_REQUEST["etaji"]);
$s_type_zdaniya = trim($_REQUEST["type_zdaniya"]);
$s_city = trim($_REQUEST["city"]);

$sEmail = trim($_REQUEST["email"]);


$priceinfo_string = '';

if (!$sName)
{
	$sName = 'Неизвестный Лид';
}


$headers = 'From: ' . $my_email . "\r\n" .
		   'Content-type: text/plain; charset=utf-8' . "\r\n" .
		   'X-Mailer: PHP/' . phpversion();
 
// include sender IP and some other data in the message
$subscribe_message = "Поступила новая заявка с сайта land.seitn.ru: " . "\n\n" .
				     ($sName ? "Имя клиента: " . $sName . "\n" : '')  .
				     ($sPhone ? "Телефон клиента: " . $sPhone . "\n" : '') .
				     ($s_city ? "Город клиента: " . $s_city . "\n" : '') .
				     ($type_obsled ? "Тип обследования: " . $type_obsled . "\n" : '') .
				     ($s_usluga ? "Тип услуги: " . $s_usluga . "\n" : '') .
				     ($s_square ? "Площадь объекта: " . $s_square . "\n" : '') .
				     ($s_etaji ? "Количество этажей: " . $s_etaji . "\n" : '') .
				     ($s_type_zdaniya ? "Тип здания: " . $s_type_zdaniya . "\n" : '') .
				     ($sComfortTime ? "Удобное время для звонка клиенту: " . $sComfortTime . "\n" : '') .
				     ($sComment ? "Комментарий клиента: " . $sComment . "\n" : '') .
				     ($sFile ? "Файл клиента: " . 'seitn.aqbe.ru/files/'.$sFile . "\n" : '') .
				     $priceinfo_string . "\n" .
				     "IP клиента: " . $_SERVER['REMOTE_ADDR'] . "\n\n";

 
// remove the backslashes from form fields
$sName = stripslashes($sName); 
$subscribe_message = stripslashes($subscribe_message); 
 
// add a prefix in the subject line so that you know the email was sent from your web site
$subject = "[Строй Эксперт Надзор LP] Поступила новая заявка от " . ($sName ? $sName : 'неизвестного человека');
$sender = $sName;

// if variables are set, send $subscribe_message to $my_email
if (isset($subscribe_message) and isset($sender)) {
		
		$result_sending = false;

		if ($sFile)
		{
			$email = new PHPMailer();
			$email->setFrom($my_email, 'Строй Эксперт Надзор');
			$email->Subject   = 'Расчет стоимости по фото';
			$email->Body = $subscribe_message;
			$email->CharSet   = 'UTF-8';
			//$email->addReplyTo($my_email_to);
			$email->addAddress($my_email_to);

			$email->addAttachment('files/' . $sFile);
			// $email->addAttachment('files/5.jpg');

			if ($email->send()) 
			{
				$result_sending = true;
			}
			else
			{
				echo 'problems_1_1 ' . $email->ErrorInfo;
			}
		}
		else
		{
			if (mail($my_email_to, $subject, $subscribe_message, $headers))
			{
				$result_sending = true;
			}
		}

		if($result_sending){
				
			if ($sEmail)
			{
				// if mail successful, send auto-reply message to subscriber's email
				$autoreply_headers = 'From: ' . $my_email . "\r\n" .
						   'Reply-To: ' . $my_email . "\r\n" .
						   'Content-type: text/plain; charset=utf-8' . "\r\n" .
						   'X-Mailer: PHP/' . phpversion();
				mail($sEmail, $autoreply_subject, "$autoreply_message", $autoreply_headers);
			}

			echo 'sended';

		}
		else
		{
			echo 'problems_1';
		}
}
else
{
	echo 'problems_2';
}

?>