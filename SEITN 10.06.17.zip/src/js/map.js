	var myMap;
	ymaps.ready(init);

	function init() {
		myMap = new ymaps.Map('YMapsID', {
			center: [59.865942, 96.504820],
			zoom: 4
		});

		myPlacemark = new Array();

		CityDatasName = new Array();
		CityDatasGD1 = new Array();
		CityDatasGD2 = new Array();

		CityDatasName[0] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Санкт-Петербург, ул. Камышовая, д.17, корп 1</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;';



		CityDatasGD2[0] = 30.423026491952;
		CityDatasGD1[0] = 60.03537779558;
		CityDatasName[1] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Санкт-Петербург, Проспект Науки, д. 23 лит А</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;';



		CityDatasGD2[1] = 30.436812103908;
		CityDatasGD1[1] = 60.0136670994;
		CityDatasName[2] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Генерала Белобородова, д. 14, корп. 1</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;';

		CityDatasGD2[2] = 37.624893798828;
		CityDatasGD1[2] = 55.748383080645;
		CityDatasName[3] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г.Нижний Новгород, Нижегородский р-н</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;';

		CityDatasGD2[3] = 44.060135498047;
		CityDatasGD1[3] = 56.453719934359;
		CityDatasName[4] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Пятигорск,пр. Кирова, 65</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;';

		CityDatasGD2[4] = 43.143821959639;
		CityDatasGD1[4] = 44.103045031299;
		CityDatasName[5] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Маршала Федоренко, д. 12</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;';

		CityDatasGD2[5] = 37.633133544922;
		CityDatasGD1[5] = 55.744510002026;
		CityDatasName[6] = "<h2>ЗАО «ТД Перекресток», универсам &quot;Пятерочка&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>М.О. Рузский район, город Руза, Волоколамское шоссе</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», универсам &quot;Пятерочка&quot;';

		CityDatasGD2[6] = 36.21771653122;
		CityDatasGD1[6] = 55.707249939143;
		CityDatasName[7] = "<h2>ЗАО «ТД Перекресток», универсам &quot;Пятерочка&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>М. О., Орехово-Зуевский р-н, Дороховское с. п. Авсюнино, ул. Вокзальная, д. 3</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», универсам &quot;Пятерочка&quot;';

		CityDatasGD2[7] = 38.193436279297;
		CityDatasGD1[7] = 56.320405799413;
		CityDatasName[8] = "<h2>ЗАО «ТД Перекресток», универсам &quot;Пятерочка&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>М.О., Шатурский район, р.п. Черусти, ул. Вокзальная</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», универсам &quot;Пятерочка&quot;';

		CityDatasGD2[8] = 39.559204024777;
		CityDatasGD1[8] = 55.579360933793;
		CityDatasName[9] = "<h2>ЗАО «ТД Перекресток», гипермаркет &quot;Карусель&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, пр-т Андропова, д. 8, ТЦ Мегаполис&quot;</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», гипермаркет &quot;Карусель&quot;';

		CityDatasGD2[9] = 37.644119873047;
		CityDatasGD1[9] = 55.739861798001;
		CityDatasName[10] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Римского-Корсакова, д. 20</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;';

		CityDatasGD2[10] = 37.621943396072;
		CityDatasGD1[10] = 55.744050109575;
		CityDatasName[11] = "<h2>ЗАО «ТД Перекресток»,  Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>Московская обл, г. Одинцово, ул. Чистяковой, д. 3</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток»,  Супермаркет &quot;Перекресток&quot;';

		CityDatasGD2[11] = 37.372208251953;
		CityDatasGD1[11] = 55.671624235848;
		CityDatasName[12] = "<h2>Закрытое акционерное общество «Мамаканская ГЭС»</h2><div class='map_shop_info'><div class='map_shop_adress'>Иркутская обл., Бодайбинский р-н., п. Мамакан, ул. Красноармейская 15</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Закрытое акционерное общество «Мамаканская ГЭС»';

		CityDatasGD2[12] = 104.2875653171;
		CityDatasGD1[12] = 52.281994171266;
		CityDatasName[13] = "<h2>ООО «Адидас»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Мурманск, ул. Героев Рыбачьего, д. 51, ТЦ “Флагман” </div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ООО «Адидас»';

		CityDatasGD2[13] = 33.34907294777;
		CityDatasGD1[13] = 69.004437675835;
		CityDatasName[14] = "<h2>ЗАО «ТД Перекресток», универсам &quot;Пятерочка&quot;, г. Челябинск</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Челябинск, ул. Правды 23</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», универсам &quot;Пятерочка&quot;, г. Челябинск';

		CityDatasGD2[14] = 61.402400952393;
		CityDatasGD1[14] = 55.16509856843;
		CityDatasName[15] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;, г. Челябинск</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Челябинск, ул. Чичерина 38 Б</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;, г. Челябинск';

		CityDatasGD2[15] = 61.298722138901;
		CityDatasGD1[15] = 55.177073211833;
		CityDatasName[16] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;, г. Оренбург</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Оренбург, ул. Гагарина 29/2</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;, г. Оренбург';

		CityDatasGD2[16] = 55.097191034393;
		CityDatasGD1[16] = 51.767906107874;
		CityDatasName[17] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;, г. Оренбург</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Оренбург, ул. 8 Марта/Володарского</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;, г. Оренбург';

		CityDatasGD2[17] = 55.104031349182;
		CityDatasGD1[17] = 51.768375811953;
		CityDatasName[18] = "<h2>ЗАО «ТД Перекресток», супермаркет &quot;Перекресток&quot;, г. Санкт-Петербург</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Санкт-Петербург, пр-т Стачек, д. 99</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», супермаркет &quot;Перекресток&quot;, г. Санкт-Петербург';

		CityDatasGD2[18] = 30.247894084656;
		CityDatasGD1[18] = 59.858871479543;
		CityDatasName[19] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;, г. Санкт-Петербург</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Санкт-Петербург, Бульвар новаторов,д. 11, корп. 2</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;, г. Санкт-Петербург';

		CityDatasGD2[19] = 30.268378830688;
		CityDatasGD1[19] = 59.849357409486;
		CityDatasName[20] = "<h2>ЗАО «ТД Перекресток», супермаркет &quot;Перекресток&quot;, г. Санкт-Петербург</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Санкт-Петербург, пр-т Энгельса, д. 120 лит «А»</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», супермаркет &quot;Перекресток&quot;, г. Санкт-Петербург';

		CityDatasGD2[20] = 30.322837932541;
		CityDatasGD1[20] = 60.037537265318;
		CityDatasName[21] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Санкт-Петербург, ул. Малая Монетная,  д. 2  лит «Г»</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;';

		CityDatasGD2[21] = 30.32163564715;
		CityDatasGD1[21] = 59.959001071768;
		CityDatasName[22] = "<h2>ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Санкт-Петербург, ул. Малая Монетная,  д. 2  лит «Г» </div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО «ТД Перекресток», Супермаркет &quot;Перекресток&quot;';

		CityDatasGD2[22] = 30.428915939368;
		CityDatasGD1[22] = 60.003706687788;
		CityDatasName[23] = "<h2>Распределительный центр Х5 Retail Group</h2><div class='map_shop_info'><div class='map_shop_adress'>Орловская область, с/п Большекуликовское, д. Крутая Гора</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Распределительный центр Х5 Retail Group';

		CityDatasGD2[23] = 36.223216;
		CityDatasGD1[23] = 52.946524;
		CityDatasName[24] = "<h2>ЗАО ТД «Перекресток»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Ульяновск, ул. Жигулевская, д. 9</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ЗАО ТД «Перекресток»';

		CityDatasGD2[24] = 48.305099;
		CityDatasGD1[24] = 54.277346;
		CityDatasName[25] = "<h2>Супермаркет «Пятерочка»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Рязань, ул. Энгельса напротив 11/37, Бронная напротив д. 7</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Супермаркет «Пятерочка»';

		CityDatasGD2[25] = 39.639123;
		CityDatasGD1[25] = 54.661578;
		CityDatasName[26] = "<h2>ООО «Адидас»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Казань, ул. проспект Победы, д. 141, СТЦ «МЕГА»</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ООО «Адидас»';

		CityDatasGD2[26] = 49.212676;
		CityDatasGD1[26] = 55.780841;
		CityDatasName[27] = "<h2>Гипермаркет «Карусель»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Рыбинск, ул. Бабушкина, д. 29</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Гипермаркет «Карусель»';

		CityDatasGD2[27] = 38.765655;
		CityDatasGD1[27] = 58.057393;
		CityDatasName[28] = "<h2>ООО «Адидас» </h2><div class='map_shop_info'><div class='map_shop_adress'>г. Магадан, ул. Портовая, д. 9</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ООО «Адидас» ';

		CityDatasGD2[28] = 150.79565;
		CityDatasGD1[28] = 59.564253;
		CityDatasName[29] = "<h2>Гипермаркет «Карусель»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Смоленск, ул. Ново-Московская, д. 2/8</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Гипермаркет «Карусель»';

		CityDatasGD2[29] = 32.044128;
		CityDatasGD1[29] = 54.782526;
		CityDatasName[30] = "<h2>Супермаркет «Перекресток», ЗАО ТД «Перекресток»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Адлер, ул. Кирова, д. 58</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Супермаркет «Перекресток», ЗАО ТД «Перекресток»';

		CityDatasGD2[30] = 39.926853;
		CityDatasGD1[30] = 43.427665;
		CityDatasName[31] = "<h2>Гипермаркет «Карусель»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Нижний Новгород, ул. Плотникова, д. 3а</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Гипермаркет «Карусель»';

		CityDatasGD2[31] = 43.856974;
		CityDatasGD1[31] = 56.259358;
		CityDatasName[32] = "<h2>Супермаркет «Перекресток», ЗАО ТД «Перекресток»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Ульяновск, ул. Жигулевская, д. 9</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Супермаркет «Перекресток», ЗАО ТД «Перекресток»';

		CityDatasGD2[32] = 48.305099;
		CityDatasGD1[32] = 54.277346;
		CityDatasName[33] = "<h2>Гипермаркет «Карусель»</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Екатаринбург, ул. Сулимова, д. 50</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Гипермаркет «Карусель»';

		CityDatasGD2[33] = 60.630874;
		CityDatasGD1[33] = 56.863434;
		CityDatasName[34] = "<h2>Складской комплекс с инфраструктурой и административными помещениями</h2><div class='map_shop_info'><div class='map_shop_adress'>Самарская обл., поселок г.т. Стройкерамика, ул. Производственная, д. 50 </div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'Складской комплекс с инфраструктурой и административными помещениями';

		CityDatasGD2[34] = 49.122476;
		CityDatasGD1[34] = 53.521473;
		CityDatasName[35] = "<h2>ТЦ «Континент» магазин «Adidas New Core», «Reebok ON OFF»</h2><div class='map_shop_info'><div class='map_shop_adress'>Новокузнецк, ул Тольятти, 46А</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ТЦ «Континент» магазин «Adidas New Core», «Reebok ON OFF»';

		CityDatasGD2[35] = 87.132941275826;
		CityDatasGD1[35] = 53.760356970489;
		CityDatasName[36] = "<h2>ТЦ «Серебряный город» Reebok</h2><div class='map_shop_info'><div class='map_shop_adress'>Иваново, ул. 8 марта, д. 32</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ТЦ «Серебряный город» Reebok';

		CityDatasGD2[36] = 40.97377915398;
		CityDatasGD1[36] = 56.995196348129;
		CityDatasName[37] = "<h2>ТРЦ «Каскад-Сити» Adidas core Reebok On Off</h2><div class='map_shop_info'><div class='map_shop_adress'>Чебоксары, Президентский б-р, д. 20</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ТРЦ «Каскад-Сити» Adidas core Reebok On Off';

		CityDatasGD2[37] = 47.244193620521;
		CityDatasGD1[37] = 56.110402588419;
		CityDatasName[38] = "<h2>ТЦ “Гудзон” Adidas</h2><div class='map_shop_info'><div class='map_shop_adress'>Новый Уренгой,  ул. Подшибякина, д. 1 корп. 2А</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ТЦ “Гудзон” Adidas';

		CityDatasGD2[38] = 76.714800346517;
		CityDatasGD1[38] = 66.091867258288;
		CityDatasName[39] = "<h2>ТЦ «Лето» Adidas new core</h2><div class='map_shop_info'><div class='map_shop_adress'>Санкт-Петербург, Пулковское ш., д. 7</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ТЦ «Лето» Adidas new core';

		CityDatasGD2[39] = 30.316259358626;
		CityDatasGD1[39] = 59.837377138536;
		CityDatasName[40] = "<h2>ТЦ «Сан Сити» магазин Adidas new core</h2><div class='map_shop_info'><div class='map_shop_adress'>Новосибирск, ул. Площадь Карла Маркса, стр. 7</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ТЦ «Сан Сити» магазин Adidas new core';

		CityDatasGD2[40] = 82.895002641094;
		CityDatasGD1[40] = 54.982135910848;
		CityDatasName[41] = "<h2>ТЦ «Россиия» магазин Reebok</h2><div class='map_shop_info'><div class='map_shop_adress'>Черкесск , ул. Ленина, д. 25</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ТЦ «Россиия» магазин Reebok';

		CityDatasGD2[41] = 42.063279671264;
		CityDatasGD1[41] = 44.224703126628;
		CityDatasName[42] = "<h2>ТЦ «Казанский» магазин Adidas FO</h2><div class='map_shop_info'><div class='map_shop_adress'>Москва, Комсомольская пл. д. 2</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'></div></div></div>" //'ТЦ «Казанский» магазин Adidas FO';

		CityDatasGD2[42] = 37.657116492155;
		CityDatasGD1[42] = 55.77489954748;
		CityDatasName[43] = "<h2>Помещения магазина H&M</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Химки, Ленинградское ш., мкр. 8</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Обследование системы вентиляции</div></div></div>" //'Помещения магазина H&M';

		CityDatasGD2[43] = 37.397439338623;
		CityDatasGD1[43] = 55.911698452991;
		CityDatasName[44] = "<h2>Распределительный центр</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Лобня, Краснополянский пр-д, д.1</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Распределительный центр';

		CityDatasGD2[44] = 37.429147068787;
		CityDatasGD1[44] = 56.01139320723;
		CityDatasName[45] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Коломна, б-р 800-летия Коломны</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[45] = 38.752391238791;
		CityDatasGD1[45] = 55.062193697071;
		CityDatasName[46] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Дмитров, ул.Загорская, вл. 26</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[46] = 37.518724374628;
		CityDatasGD1[46] = 56.342247142703;
		CityDatasName[47] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Климовск, ул. Симферопольская, д.35</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[47] = 37.532823626984;
		CityDatasGD1[47] = 55.367903894839;
		CityDatasName[48] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Чехов, ул. Московская, вл. 96</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[48] = 37.465583350838;
		CityDatasGD1[48] = 55.153182437845;
		CityDatasName[49] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>Ивановская обл., г. Иваново, пр. Фридриха Энгельса, д.89</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[49] = 40.988028219574;
		CityDatasGD1[49] = 57.008993878387;
		CityDatasName[50] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Одинцово, ул. Неделина, д.6</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[50] = 37.268103390213;
		CityDatasGD1[50] = 55.678474439611;
		CityDatasName[51] = "<h2>Гипермаркет &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Рязань, р-н Дегилево</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Гипермаркет &quot;Перекресток&quot;';

		CityDatasGD2[51] = 39.722924593414;
		CityDatasGD1[51] = 54.607174901173;
		CityDatasName[52] = "<h2>Дискаунтер &quot;Пятерочка&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Владимир, ул. Соколова-Соколенка, д.17</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Дискаунтер &quot;Пятерочка&quot;';

		CityDatasGD2[52] = 40.453263915344;
		CityDatasGD1[52] = 56.168411985791;
		CityDatasName[53] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>Солнечногорский р-н, д. Голиково, ул. Горетовская, д.1</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[53] = 37.288535767212;
		CityDatasGD1[53] = 55.931790638252;
		CityDatasName[54] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Троицк, ул. Горская, вл.6</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[54] = 37.297478984131;
		CityDatasGD1[54] = 55.473251907473;
		CityDatasName[55] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, п. Томилино, Егорьевское ш., д.1</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[55] = 37.929721746033;
		CityDatasGD1[55] = 55.658955608171;
		CityDatasName[56] = "<h2>Садовый дом</h2><div class='map_shop_info'><div class='map_shop_adress'>Тверская обл., д. Макарьево</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Техническое обследование</div></div></div>" //'Садовый дом';

		CityDatasGD2[56] = 32.980786555542;
		CityDatasGD1[56] = 56.088239986747;
		CityDatasName[57] = "<h2>Гипермаркет &quot;Пятерочка&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Рязань, Заводской пр-д, д.1</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Гипермаркет &quot;Пятерочка&quot;';

		CityDatasGD2[57] = 39.702676253967;
		CityDatasGD1[57] = 54.631948569123;
		CityDatasName[58] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Балашиха, ул. Зеленая, к.2</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[58] = 37.943235542328;
		CityDatasGD1[58] = 55.807342126587;
		CityDatasName[59] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, Истринский р-н, д. Новинки</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[59] = 37.137641674435;
		CityDatasGD1[59] = 55.810435028343;
		CityDatasName[60] = "<h2>Гипермаркет &quot;Пятерочка&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Кострома, ул. Поселковая, д.37</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Гипермаркет &quot;Пятерочка&quot;';

		CityDatasGD2[60] = 40.967034219574;
		CityDatasGD1[60] = 57.777486488351;
		CityDatasName[61] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Королев, ул. Космонавтов, д.27б</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[61] = 37.868187930443;
		CityDatasGD1[61] = 55.913430134487;
		CityDatasName[62] = "<h2>Производственное помещение</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Домодедово, ул. Краснодарская, д.1</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Производственное помещение';

		CityDatasGD2[62] = 37.75684982406;
		CityDatasGD1[62] = 55.459752761127;
		CityDatasName[63] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Химки, ул. Кудрявцева, д.4</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[63] = 37.457795920014;
		CityDatasGD1[63] = 55.898081955324;
		CityDatasName[64] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Серпухов, Борисовское ш., д.5</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[64] = 37.428171566223;
		CityDatasGD1[64] = 54.916884574651;
		CityDatasName[65] = "<h2>Больничный комплекс</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Балашиха, ш. Энтузиастов, д.12</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Больничный комплекс';

		CityDatasGD2[65] = 37.922605592153;
		CityDatasGD1[65] = 55.792244613078;
		CityDatasName[66] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>МО, г. Королев, ул. Космонавтов, д.41</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[66] = 37.867297811801;
		CityDatasGD1[66] = 55.90792846427;
		CityDatasName[67] = "<h2>Промышленное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Шверника, д.4, с.1</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Освидетельствование качества выполненных работ</div></div></div>" //'Промышленное здание';

		CityDatasGD2[67] = 37.579385779099;
		CityDatasGD1[67] = 55.692983459937;
		CityDatasName[68] = "<h2>Офисные помещения</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Летниковская, д.10., к.4</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Экспертиза качества выполненных работ</div></div></div>" //'Офисные помещения';

		CityDatasGD2[68] = 37.642518711639;
		CityDatasGD1[68] = 55.724811889886;
		CityDatasName[69] = "<h2>Жилой дом</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Гризобутовой, д.1, к.4</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Тепловизионное обследование фасада</div></div></div>" //'Жилой дом';

		CityDatasGD2[69] = 37.532090906746;
		CityDatasGD1[69] = 55.781564768936;
		CityDatasName[70] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Вавилова, д.69/75</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[70] = 37.551296906746;
		CityDatasGD1[70] = 55.682274321598;
		CityDatasName[71] = "<h2>Офисные помещения</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Новослабодская, д.41</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Экспертиза вентиляционной системы</div></div></div>" //'Офисные помещения';

		CityDatasGD2[71] = 37.59694682209;
		CityDatasGD1[71] = 55.783342816254;
		CityDatasName[72] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Профсоюзная, д.118</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[72] = 37.518383813492;
		CityDatasGD1[72] = 55.636371999994;
		CityDatasName[73] = "<h2>Административно-производственное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, Кутузовский пр-т, д.17</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Административно-производственное здание';

		CityDatasGD2[73] = 37.556671898148;
		CityDatasGD1[73] = 55.746921206447;
		CityDatasName[74] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Бауманская, д.62-66</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[74] = 37.678848084656;
		CityDatasGD1[74] = 55.765848026924;
		CityDatasName[75] = "<h2>Больничный комплекс</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Щепкина, д.61/2</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Больничный комплекс';

		CityDatasGD2[75] = 37.627776338623;
		CityDatasGD1[75] = 55.784711908548;
		CityDatasName[76] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, б-р Адмирала Ушакова, д.7</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';



		CityDatasGD2[76] = 37.551274915344;
		CityDatasGD1[76] = 55.546282668689;
		CityDatasName[77] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул Старокачаловская, д. 1б</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[77] = 37.585514746033;
		CityDatasGD1[77] = 55.568515444409;
		CityDatasName[78] = "<h2>Помещения магазина H&M</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, Ленинградское ш., д.16</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Обследование системы вентиляции</div></div></div>" //'Помещения магазина H&M';

		CityDatasGD2[78] = 37.497795182077;
		CityDatasGD1[78] = 55.821338211685;
		CityDatasName[79] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Азовская, вл. 28В</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[79] = 37.593741550275;
		CityDatasGD1[79] = 55.643772188752;
		CityDatasName[80] = "<h2>Выставочный комплекс</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Образцова, д.19</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Техническое обследование монтажа кровли</div></div></div>" //'Выставочный комплекс';

		CityDatasGD2[80] = 37.608044813492;
		CityDatasGD1[80] = 55.789286315092;
		CityDatasName[81] = "<h2>Административно-производственное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Удальцова, д.85</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Техническое обследование состояния объекта</div></div></div>" //'Административно-производственное здание';

		CityDatasGD2[81] = 37.487538720273;
		CityDatasGD1[81] = 55.683330873265;
		CityDatasName[82] = "<h2>Жилой дом</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, Сытинский тупик, д. 3</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Обследование на предмет выявления появления дефектов</div></div></div>" //'Жилой дом';

		CityDatasGD2[82] = 37.600204542328;
		CityDatasGD1[82] = 55.764204097834;
		CityDatasName[83] = "<h2>Здание института</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Радио, д.17 к.5</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Обследование элементов ограждающих и несущих конструкций</div></div></div>" //'Здание института';

		CityDatasGD2[83] = 37.678969253967;
		CityDatasGD1[83] = 55.763656343047;
		CityDatasName[84] = "<h2>Головной офис Samsung</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Тверская, д.22</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами.</div></div></div>" //'Головной офис Samsung';

		CityDatasGD2[84] = 37.602141529877;
		CityDatasGD1[84] = 55.767920617109;
		CityDatasName[85] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Нежинская, д.6</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[85] = 37.470693195013;
		CityDatasGD1[85] = 55.710014406425;
		CityDatasName[86] = "<h2>Больничный комплекс</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Россолимо, д.11</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Техническое обследование здания</div></div></div>" //'Больничный комплекс';

		CityDatasGD2[86] = 37.581383695313;
		CityDatasGD1[86] = 55.734919318134;
		CityDatasName[87] = "<h2>Здание юридической академии</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, Измайловская площадь, д. 5, к. 2</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами</div></div></div>" //'Здание юридической академии';

		CityDatasGD2[87] = 37.773807354265;
		CityDatasGD1[87] = 55.792660082065;
		CityDatasName[88] = "<h2>Универсам &quot;Перекресток&quot;</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, Ангелов Переулок, д.7</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Технический надзор за ремонтно-строительныим работами.</div></div></div>" //'Универсам &quot;Перекресток&quot;';

		CityDatasGD2[88] = 37.347700482396;
		CityDatasGD1[88] = 55.851641503897;
		CityDatasName[89] = "<h2>Офисные помещения</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Летниковская, д. 10, стр 4</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Полное техническое сопровождение при приемке выполненных работ от Подрядной организации</div></div></div>" //'Офисные помещения';

		CityDatasGD2[89] = 37.642563491255;
		CityDatasGD1[89] = 55.724844343272;
		CityDatasName[90] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, Ленинский пр-т, д.7 а</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Комплексное обследование здания</div></div></div>" //'Административное здание';

		CityDatasGD2[90] = 37.607349532118;
		CityDatasGD1[90] = 55.725001507867;

		CityDatasName[92] = "<h2>Административное здание</h2><img class='map_shop_img' src='/upload/iblock/37a/ynwfuvjojv 62.JPG' width='53' height='53' alt='Административное здание' title='Административное здание' /><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, Волоколамское ш.,  д.62</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Обследование контрукций кровли, колонн, расчет несущей способности</div></div></div>" //'Административное здание';

		CityDatasGD2[92] = 37.617635;
		CityDatasGD1[92] = 55.755814;
		CityDatasName[93] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Новый Уренгой</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Обследование контрукций кровли, колонн, расчет несущей способности</div></div></div>" //'Административное здание';

		CityDatasGD2[93] = 64.061091;
		CityDatasGD1[93] = 67.497410;

		CityDatasName[94] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Воркута</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';

		CityDatasGD2[94] = 142.750797;
		CityDatasGD1[94] = 50.150926;
		CityDatasName[95] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>Сахалин</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[95] = 33.525432;
		CityDatasGD1[95] = 44.616687;

		CityDatasName[96] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Севастополь</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[96] = 33.525432;
		CityDatasGD1[96] = 44.616687;

		CityDatasName[97] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Новороссийск</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[97] = 37.768678;
		CityDatasGD1[97] = 44.723566;

		CityDatasName[98] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Ростов-на-Дону</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[98] = 39.718669;
		CityDatasGD1[98] = 47.222513;

		CityDatasName[99] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Краснодар</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[99] = 38.992615;
		CityDatasGD1[99] = 45.057626;

		CityDatasName[100] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Казань</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[100] = 49.106324;
		CityDatasGD1[100] = 55.798551;

		CityDatasName[101] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Хатанга</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[101] = 102.483410;
		CityDatasGD1[101] = 71.980467;

		CityDatasName[102] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Новосибирск</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[102] = 82.920430;
		CityDatasGD1[102] = 55.030199;

		CityDatasName[103] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Магадан</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[103] = 150.808541;
		CityDatasGD1[103] = 59.568164;

		CityDatasName[104] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Сочи</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[104] = 39.723062;
		CityDatasGD1[104] = 43.585525;

		CityDatasName[105] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Якутск</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[105] = 129.732555;
		CityDatasGD1[105] = 62.028098;

		CityDatasName[106] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Иркутск</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[106] = 104.280660;
		CityDatasGD1[106] = 52.286387;

		CityDatasName[107] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Владивосток</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[107] = 131.885341;
		CityDatasGD1[107] = 43.115141;

		CityDatasName[108] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Улан-Удэ</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[108] = 107.584125;
		CityDatasGD1[108] = 51.833507;

		CityDatasName[109] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Анадырь</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[109] = 177.514745;
		CityDatasGD1[109] = 64.734816;

		CityDatasName[110] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Мирный</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[110] = 113.978692;
		CityDatasGD1[110] = 62.541028;

		CityDatasName[111] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Ялта</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[111] = 34.166353;
		CityDatasGD1[111] = 44.495273;

		CityDatasName[112] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Петропавловск Камчатский</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[112] = 158.655918;
		CityDatasGD1[112] = 53.037040;

		CityDatasName[113] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Салехард</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[113] = 66.613851;
		CityDatasGD1[113] = 66.530715;

		CityDatasName[114] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Благовещенск</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[114] = 127.527173;
		CityDatasGD1[114] = 50.290658;

		CityDatasName[115] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Мурманск</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[115] = 33.074558;
		CityDatasGD1[115] = 68.969582;

		CityDatasName[116] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Томск</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[116] = 84.948197;
		CityDatasGD1[116] = 56.484680;

		CityDatasName[117] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Санкт Петербург</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[117] = 30.315868;
		CityDatasGD1[117] = 59.939095;

		CityDatasName[118] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Нижневартовск</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[118] = 76.569601;
		CityDatasGD1[118] = 60.939742;

		CityDatasName[119] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Екатеринбург</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[119] = 60.605514;
		CityDatasGD1[119] = 56.838607;

		CityDatasName[120] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Сыктывкар</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[120] = 50.835770;
		CityDatasGD1[120] = 61.668724;

		CityDatasName[121] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Нижневартовск</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>---</div></div></div>" //'Административное здание';
		CityDatasGD2[121] = 76.569601;
		CityDatasGD1[121] = 60.939742;

		CityDatasName[122] = "<h2>Административное здание</h2><div class='map_shop_info'><div class='map_shop_adress'>г. Москва, ул. Братеевская, вл 21, корп. 1А</div><div class='map_shop_phone'></div>8 (800) 333-98-56<div class='map_shop_anounce'>Техническая экспертиза состояния здания на предмет капитальности</div></div></div>" //'Административное здание';
		CityDatasGD2[122] = 37.764115;
		CityDatasGD1[122] = 55.634852;


		for (var key in CityDatasName) {
			myPlacemark[key] = new ymaps.Placemark([CityDatasGD1[key], CityDatasGD2[key]], {

			}, {
				iconImageHref: 'map-icon.png',
				iconImageSize: [29, 37],
				iconImageOffset: [-15, -30],
				openEmptyBalloon: true,
				iconContentSize: [24, 16],
				iconContentOffset: [-8, -10],
				openEmptyBalloon: true,
				hideIconOnBalloonOpen: false
			});
			myPlacemark[key].key = key;

			myPlacemark[key].events.add('balloonopen', getAddress);

			myMap.geoObjects.add(myPlacemark[key]);
		}

		function getAddress(e) {
			var obj = e.get('target');

			obj.properties.set('balloonContent', CityDatasName[obj.key]);
		}

		myMap.controls.add('zoomControl', {
			left: 5,
			top: 5
		});

	}