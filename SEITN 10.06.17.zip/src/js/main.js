"use strict";

$(function(){

	$(document).ready(function(){

		//navigation scroll to
		$("section").on("click","a", function (event) {
			//отменяем стандартную обработку нажатия по ссылке
			event.preventDefault();
			//забираем идентификатор бока с атрибута href
			var id  = $(this).attr('href'),
			//узнаем высоту от начала страницы до блока на который ссылается якорь
			top = $(id).offset().top;
			//анимируем переход на расстояние - top за 1000 мс
			$('body,html').animate({scrollTop: top}, 1000);
		});

		//wow animate initial
		// new WOW().init();

	$('input').change(function() {
		var fileName = $('#filename').html(); 
		$('#from_file').val(fileName);
	});

 
	var files;
	// Вешаем функцию на событие
	// Получим данные файлов и добавим их в переменную 
	$('input[type=file]').change(function(event){
		files = this.files;
		event.stopPropagation(); // Остановка происходящего
		event.preventDefault();  // Полная остановка происходящего
		// Создадим данные формы и добавим в них данные файлов из files
		var data = new FormData();
		$.each( files, function( key, value ){
		    data.append( key, value );
		});
		// Отправляем запрос
		$.ajax({
		    url: './submit.php?uploadfiles',
		    type: 'POST',
		    data: data,
		    cache: false,
		    dataType: 'json',
		    processData: false, // Не обрабатываем файлы (Don't process the files)
		    contentType: false, // Так jQuery скажет серверу что это строковой запрос
		    success: function( respond, textStatus, jqXHR ){
		        // Если все ОК
		        if( typeof respond.error === 'undefined' ){
		            // Файлы успешно загружены, делаем что нибудь здесь
		            // выведем пути к загруженным файлам в блок '.ajax-respond'
		            var files_path = respond.files;
		            var html = '';
		            $.each( files_path, function( key, val ){ html += val +'<br>'; } )
		            $('.ajax-respond').html( html );
		        }
		        else{
		            console.log('ОШИБКИ ОТВЕТА сервера: ' + respond.error );
		        }
		    },
		    error: function( jqXHR, textStatus, errorThrown ){
		        console.log('ОШИБКИ AJAX запроса: ' + textStatus );
		    }
		});
	});




//AJAX email send
	$('form').submit(function(event) {
		event.preventDefault();

		var id = $(this).attr('id');
		var data = $(this).serialize();
		

		$.ajax({
			url				: '/emailOrder.php',
			data			: data,
			type			: 'post',
			beforeSend: function(){
				$.arcticmodal('close');
			},
			success		: function(){
				/*затираем введенные данные в полях ввода, чтобы показать, что форма обработана*/
				$('input[type=text], input[type=tel], textarea, input[type=email]').val('');
				/*Показвем сообщение об успешном завершении*/
				$('#success-modal').arcticmodal();
			},
			error			: function(){
				alert('Ошибка при отправке формы.');
			},
			//complete	: function(){
				
			//}
		});
	});



	// кнопки меню в адаптивке
	$('.close-btn, .mobile-menu a').click(function() {$('.mobile-menu').removeClass('active');});
	$('.hamb-btn').click(function() {$('.mobile-menu').addClass('active');});


	// вызов всплывающего окна
	$('.callback-btn').click(function() {$('#callback-modal').arcticmodal();});
	$('.file-modal-btn').click(function() {$('#file-modal').arcticmodal();});
	$('.stoimost-btn').click(function() {$('#stoimost-modal').arcticmodal();});
	$('.stoimost-btn_2').click(function() {
		if($('.telephone-input').val() != '') {
			$('.second-step').fadeIn();
		} else {alert('Добавьте номер телефона.');}
	});


	//стилизация инпут файл
	$(".file-upload input[type=file]").change(function(){
		var filename = $(this).val().replace(/.*\\/, "");
		$("#filename").html(filename);

		$("#success-download").html('Загрузка файла');
		$(".cssload-jumping").fadeIn();
		setTimeout(function() {
			$("#success-download").html('Файл загружен');
			$(".cssload-jumping").fadeOut();
		}, 4000);
	});

	//подбор стоимости услуги
	$("#submit-form").on("click", function() {
		var select_val = $("#square_1").val();
		var usluga_val = $("#type_obsled").val();

		if(select_val == "до 500 м2") {$("#price-p").html("от 135 250 руб.");}
		if(select_val == "от 500 до 10000 м2") {$("#price-p").html("260 000 руб.");}
		if(select_val == "от 10000 м2") {$("#price-p").html("от 260 000 руб.");}
		if(usluga_val == "Технадзор") {$("#price-p").html("от 7 500 руб./выезд");}
	});

	//инициализация слайдера
	var owl1 = $('.clients-slider').owlCarousel({
		loop:true,
		slideSpeed : 300,
		paginationSpeed : 400,
		pagination: false,
		rewindSpeed: 500,
		items:1
	});

	$("#owl-prev1").click(function () {owl1.trigger('prev.owl.carousel');});
	$("#owl-next1").click(function () {owl1.trigger('next.owl.carousel');});

	var owl = $('.owl-carousel1').owlCarousel({
		loop:true,
		// center:true,
		// margin:10,
		slideSpeed : 300,
		paginationSpeed : 400,
		pagination: false,
		rewindSpeed: 500,
		responsive:{
			0:{
				items:2
			},
			400:{
				items:2
			},
			600:{
				items:3
			},
			1000:{
				items:5
			}
		}
	});

	$("#owl-prev").click(function () {owl.trigger('prev.owl.carousel');});
	$("#owl-next").click(function () {owl.trigger('next.owl.carousel');});

	var owl2 = $('.owl-carousel2').owlCarousel({
		loop:true,
		// center:true,
		// margin:10,
		slideSpeed : 300,
		paginationSpeed : 400,
		pagination: false,
		rewindSpeed: 500,
		responsive:{
			0:{
				items:2
			},
			400:{
				items:2
			},
			600:{
				items:3
			},
			1000:{
				items:5
			}
		}
	});

	$("#owl-prev2").click(function () {owl2.trigger('prev.owl.carousel');});
	$("#owl-next2").click(function () {owl2.trigger('next.owl.carousel');});

	var owl3 = $('.owl-carousel3').owlCarousel({
		loop:true,
		// center:true,
		// margin:10,
		slideSpeed : 300,
		paginationSpeed : 400,
		pagination: false,
		rewindSpeed: 500,
		responsive:{
			0:{
				items:1
			},
			600:{
				items:2
			},
			1000:{
				items:3
			},
			1400:{
				items:3
			}
		}
	});

	$("#owl-prev3").click(function () {owl3.trigger('prev.owl.carousel');});
	$("#owl-next3").click(function () {owl3.trigger('next.owl.carousel');});

	var specs = $('.owl-specs').owlCarousel({
		loop:true,
		slideSpeed : 300,
		paginationSpeed : 400,
		pagination: false,
		rewindSpeed: 500,
		items:1
	});

	$("#owl-prev4").click(function () {specs.trigger('prev.owl.carousel');});
	$("#owl-next4").click(function () {specs.trigger('next.owl.carousel');});

	var equip = $('.owl-equip').owlCarousel({
		loop:true,
		slideSpeed : 300,
		paginationSpeed : 400,
		pagination: false,
		rewindSpeed: 500,
		items:1
	});

	$("#owl-prev5").click(function () {equip.trigger('prev.owl.carousel');});
	$("#owl-next5").click(function () {equip.trigger('next.owl.carousel');});

	$('.owl-photo').magnificPopup({
			type: 'image',
			closeOnContentClick: true,
			closeBtnInside: false,
			fixedContentPos: true,
			mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
			image: {
				verticalFit: true
			},
			zoom: {
				enabled: true,
				duration: 300 // don't foget to change the duration also in CSS
			}
		});

	//bag Firefox arcticmodal
	$("body").click(function(){$(this).css('overflow-y','visible')})

	$('.load-projects').click(function() {
		$('.projects-page-2').addClass('active');
		if($('.projects-page-2').hasClass('active')) {
			$(this).hide();
		}
	});



























	// START TYPEAHEAD AUTOCOMLETE
	   var substringMatcher = function(strs) {
	     return function findMatches(q, cb) {
	       var matches, substringRegex;

	       // an array that will be populated with substring matches
	       matches = [];

	       // regex used to determine if a string contains the substring `q`
	       var substrRegex = new RegExp(q, 'i');

	       // iterate through the pool of strings and for any string that
	       // contains the substring `q`, add it to the `matches` array
	       $.each(strs, function(i, str) {
	         if (substrRegex.test(str)) {
	           matches.push(str);
	         }
	       });

	       cb(matches);
	     };
	   };

	   var cities = ['Абакан', 'Азов', 'Александров', 'Алексин', 'Альметьевск', 'Анапа', 'Ангарск', 'Анжеро-Судженск', 'Апатиты', 'Арзамас', 'Армавир', 'Арсеньев', 'Артем', 'Архангельск', 'Асбест', 'Астрахань', 'Ачинск', 'Балаково', 'Балахна', 'Балашиха', 'Балашов', 'Барнаул', 'Батайск', 'Белгород', 'Белебей', 'Белово', 'Белогорск', 'Белорецк', 'Белореченск', 'Бердск', 'Березники', 'Бийск', 'Биробиджан', 'Благовещенск', 'Бор', 'Борисоглебск', 'Боровичи', 'Братск', 'Брянск', 'Бугульма', 'Бугуруслан', 'Будённовск', 'Бузулук', 'Буйнакск', 'Великие Луки', 'Великий Новгород', 'Верхняя Пышма', 'Верхняя Салда', 'Видное', 'Владивосток', 'Владикавказ', 'Владимир', 'Волгоград', 'Волгодонск', 'Волжск', 'Волжский', 'Вологда', 'Вольск', 'Воркута', 'Воронеж', 'Воскресенск', 'Воткинск', 'Выборг', 'Выкса', 'Вышний Волочек', 'Вязьма', 'Гатчина', 'Геленджик', 'Георгиевск', 'Глазов', 'Горно-Алтайск', 'Грозный', 'Губкин', 'Гуково', 'Гусь-Хрустальный', 'Дербент', 'Дзержинск', 'Димитровград', 'Дмитров', 'Долгопрудный', 'Домодедово', 'Дубна', 'Егорьевск', 'Ейск', 'Екатеринбург', 'Елабуга', 'Елец', 'Ессентуки', 'Железногорск (Красноярский край)' , 'Железногорск (Курская обл.)', 'Железнодорожный', 'Жуковский', 'Заречный', 'Заринск', 'Зеленогорск', 'Зеленоград', 'Зеленодольск', 'Златоуст', 'Иваново', 'Ивантеевка', 'Ижевск', 'Иркутск', 'Искитим', 'Ишим', 'Ишимбай', 'Йошкар-Ола', 'Казань', 'Калининград', 'Калуга', 'Каменск-Уральский', 'Каменск-Шахтинский', 'Камышин', 'Канаш', 'Канск', 'Каспийск', 'Кемерово', 'Кимры', 'Кингисепп', 'Кинешма', 'Кириши', 'Киров', 'Кирово-Чепецк', 'Киселевск', 'Кисловодск', 'Климовск', 'Клин', 'Клинцы', 'Ковров', 'Когалым', 'Коломна', 'Комсомольск-на-Амуре', 'Копейск', 'Королёв', 'Кострома', 'Котлас', 'Красногорск', 'Краснодар', 'Краснокаменск', 'Краснокамск', 'Краснотурьинск', 'Красноярск', 'Кропоткин', 'Крымск', 'Кстово', 'Кузнецк', 'Кумертау', 'Кунгур', 'Курган', 'Курск', 'Кызыл', 'Лабинск', 'Лениногорск', 'Ленинск-Кузнецкий', 'Лесной', 'Лесосибирск', 'Ливны', 'Липецк', 'Лиски', 'Лобня', 'Лысьва', 'Лыткарино', 'Люберцы', 'Магадан', 'Магнитогорск', 'Майкоп', 'Махачкала', 'Междуреченск', 'Мелеуз', 'Миасс', 'Минеральные Воды', 'Минусинск', 'Михайловка', 'Михайловск', 'Мичуринск', 'Мончегорск', 'Москва', 'Мурманск', 'Муром', 'Мытищи', 'Набережные Челны', 'Назарово', 'Назрань', 'Нальчик', 'Наро-Фоминск', 'Находка', 'Невинномысск', 'Нерюнгри', 'Нефтекамск', 'Нефтеюганск', 'Нижневартовск', 'Нижнекамск', 'Нижний Новгород', 'Нижний Тагил', 'Новоалтайск', 'Новокузнецк', 'Новокуйбышевск', 'Новомосковск', 'Новороссийск', 'Новосибирск', 'Новотроицк', 'Новоуральск', 'Новочебоксарск', 'Новочеркасск', 'Новошахтинск', 'Новый Уренгой', 'Ногинск', 'Норильск', 'Ноябрьск', 'Нягань', 'Обнинск', 'Одинцово', 'Озерск', 'Октябрьский', 'Омск', 'Орел', 'Оренбург', 'Орехово-Зуево', 'Орск', 'Осинники', 'Отрадный', 'Павлово', 'Павловский Посад', 'Пенза', 'Первоуральск', 'Пермь', 'Петрозаводск', 'Петропавловск-Камчатский', 'Подольск', 'Полевской', 'Прокопьевск', 'Прохладный', 'Псков', 'Пушкино', 'Пятигорск', 'Раменское', 'Ревда', 'Реутов', 'Ржев', 'Рославль', 'Россошь', 'Ростов-на-Дону', 'Рубцовск', 'Рыбинск', 'Рязань', 'Салават', 'Сальск', 'Самара', 'Санкт-Петербург', 'Саранск', 'Сарапул', 'Саратов', 'Саров', 'Саяногорск', 'Свободный', 'Северодвинск', 'Североморск', 'Северск', 'Сергиев Посад', 'Серов', 'Серпухов', 'Сибай', 'Славянск-на-Кубани', 'Смоленск', 'Снежинск', 'Соликамск', 'Солнечногорск', 'Сосновый Бор', 'Сочи', 'Спасск-Дальний', 'Ставрополь', 'Старый Оскол', 'Стерлитамак', 'Ступино', 'Сургут', 'Сызрань', 'Сыктывкар', 'Таганрог', 'Талнах', 'Тамбов', 'Тверь', 'Тимашевск', 'Тихвин', 'Тихорецк', 'Тобольск', 'Тольятти', 'Томск', 'Троицк', 'Туапсе', 'Туймазы', 'Тула', 'Тулун', 'Тюмень', 'Узловая', 'Улан-Удэ', 'Ульяновск', 'Усолье-Сибирское', 'Уссурийск', 'Усть-Илимск', 'Уфа', 'Ухта', 'Фрязино', 'Хабаровск', 'Ханты-Мансийск', 'Хасавюрт', 'Химки', 'Чайковский', 'Чапаевск', 'Чебоксары', 'Челябинск', 'Черемхово', 'Череповец', 'Черкесск', 'Черногорск', 'Чехов', 'Чистополь', 'Чита', 'Чусовой', 'Шадринск', 'Шахты', 'Шуя', 'Щекино', 'Щёлково', 'Электросталь', 'Элиста', 'Энгельс', 'Южно-Сахалинск', 'Юрга', 'Якутск', 'Ярославль', 'Ярцево'];

		$('input#cities-input').typeahead({
			hint: true,
			highlight: true,
			minLength: 1
		},
		{
			name: 'cities',
			source: substringMatcher(cities)
		});
	   // END TYPEAHEAD AUTOCOMLETE



	/* Specialists */
	$(document).on('click', '.b-block_specialists-controls__item_right', function(event){
	    var _s_position = parseInt($('.b-block_specialists-people').attr('data-position'));
	    var _s_num = parseInt($('.b-block_specialists-people').attr('data-num'));
	    var _s_slide = parseInt($('.b-block_specialists-people').attr('data-slide'));
	    var next_item = ($('.b-block_specialists-people__item_active').next().length > 0 ? $('.b-block_specialists-people__item_active').next() : $('.b-block_specialists-people__item:first'));
	    var next_show = ($('.b-block_specialists-people__item:not(.b-block_specialists-people__item_hidden):last').next().length > 0 ? $('.b-block_specialists-people__item:not(.b-block_specialists-people__item_hidden):last').next() : false);

	    if (_s_position <= _s_slide)
	    {
	        $('.b-block_specialists-people__item_active').addClass('b-block_specialists-people__item_hidden');

	        $(next_show).removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item').css("left", "-=" + $(next_item).position().left);
	    }

	    $('.b-block_specialists-people').attr('data-position', $(next_item).attr('data-id'));
	    _s_position = $(next_item).attr('data-id');

	    $('.b-block_specialists-people__item_active').removeClass('b-block_specialists-people__item_active');
	    $(next_item).addClass('b-block_specialists-people__item_active');

	    $('.b-block_specialists__item_active').removeClass('b-block_specialists__item_active');
	    $('.b-block_specialists__item_' + $(next_item).attr('data-id')).addClass('b-block_specialists__item_active');

	    if ($(next_item).attr('data-id') == '1')
	    {
	        $('.b-block_specialists-people__item').attr('style', '');

	        $('.b-block_specialists-people__item_1').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_2').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_3').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_4').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_5').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_6').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_7').removeClass('b-block_specialists-people__item_hidden');

	        $('.b-block_specialists-people__item_8').addClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_9').addClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_10').addClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_11').addClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_12').addClass('b-block_specialists-people__item_hidden');
	    }
	});

	$(document).on('click', '.b-block_specialists-controls__item_left', function(event){
	    var _s_position = parseInt($('.b-block_specialists-people').attr('data-position'));
	    var _s_num = parseInt($('.b-block_specialists-people').attr('data-num'));
	    var _s_slide = parseInt($('.b-block_specialists-people').attr('data-slide'));
	    var next_item = ($('.b-block_specialists-people__item_active').prev().length > 0 ? $('.b-block_specialists-people__item_active').prev() : $('.b-block_specialists-people__item:last'));
	    var next_show = ($('.b-block_specialists-people__item:not(.b-block_specialists-people__item_hidden):first').prev().length > 0 ? $('.b-block_specialists-people__item:not(.b-block_specialists-people__item_hidden):first').prev() : false);

	    if (_s_position <= _s_slide + 1)
	    {
	        $('.b-block_specialists-people__item:not(.b-block_specialists-people__item_hidden):last').addClass('b-block_specialists-people__item_hidden');

	        $(next_show).removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item').css("left", "-=" + $(next_item).position().left);
	    }

	    $('.b-block_specialists-people').attr('data-position', $(next_item).attr('data-id'));
	    _s_position = $(next_item).attr('data-id');

	    $('.b-block_specialists-people__item_active').removeClass('b-block_specialists-people__item_active');
	    $(next_item).addClass('b-block_specialists-people__item_active');

	    $('.b-block_specialists__item_active').removeClass('b-block_specialists__item_active');
	    $('.b-block_specialists__item_' + $(next_item).attr('data-id')).addClass('b-block_specialists__item_active');

	    if ($(next_item).attr('data-id') == '11')
	    {
	        $('.b-block_specialists-people__item_5').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_6').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_7').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_8').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_9').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_10').removeClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_11').removeClass('b-block_specialists-people__item_hidden');

	        $('.b-block_specialists-people__item_1').addClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_2').addClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_3').addClass('b-block_specialists-people__item_hidden');
	        $('.b-block_specialists-people__item_4').addClass('b-block_specialists-people__item_hidden');

	        $('.b-block_specialists-people__item_1').css('left', '-532px');
	        $('.b-block_specialists-people__item_2').css('left', '-397px');
	        $('.b-block_specialists-people__item_3').css('left', '-243px');
	        $('.b-block_specialists-people__item_4').css('left', '-123px');
	        $('.b-block_specialists-people__item_5').css('left', '0px');
	        $('.b-block_specialists-people__item_6').css('left', '73px');
	        $('.b-block_specialists-people__item_7').css('left', '223px');
	        $('.b-block_specialists-people__item_8').css('left', '359px');
	        $('.b-block_specialists-people__item_9').css('left', '463px');
	        $('.b-block_specialists-people__item_10').css('left', '593px');
	        $('.b-block_specialists-people__item_11').css('left', '753px');
	    }
	});

	$(document).on('click', '.b-block_specialists-people__item', function(event){
	    var need_item = $(this);
	    $('.b-block_specialists-people__item').each(function(item){
	        if ($(need_item).attr('data-id') != $('.b-block_specialists-people__item_active').attr('data-id'))
	        {
	            $('.b-block_specialists-controls__item_right').click();
	        }
	    });
	});
	/* \Specialists */


	/* Equipment */
    var _equipment_delay = 15000;
    var _equipment_mouseover = false;
    var _equipment_timeouts = [];

    $('.b-block_equipment-controls__item').hover(
        function () {
            _equipment_mouseover = true;
        },
        function () {
            _equipment_mouseover = false;
        }
    );

    $(document).on('click', '.b-block_equipment-controls__item_left', function(event){
        var next_item = ($('.b-block_equipment__item_active').prev().length > 0 ? $('.b-block_equipment__item_active').prev() : $('.b-block_equipment__item:last'));

        $('.b-block_equipment__item_active').removeClass('b-block_equipment__item_active');
        $(next_item).addClass('b-block_equipment__item_active');

        $('.b-block_equipment-mini__item_active').removeClass('b-block_equipment-mini__item_active');
        $('.b-block_equipment-mini__item_' + $(next_item).attr('data-id')).addClass('b-block_equipment-mini__item_active');

        if (parseInt($(next_item).attr('data-id')) > 8)
        {
            $('.b-block_equipment-mini__item').removeClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item_1').addClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item_2').addClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item_3').addClass('b-block_equipment-mini__item_hidden');
        }
        else
        {
            $('.b-block_equipment-mini__item').removeClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item_9').addClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item_10').addClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item_11').addClass('b-block_equipment-mini__item_hidden');
        }

        for(var i = 0, z = _equipment_timeouts.length; i < z; i++)
        {
            clearTimeout(_equipment_timeouts[i]);
        }

        _equipment_timeouts = [];

        _equipment_timeouts.push(setTimeout(function(){
            rotateEquipment();
        }, _equipment_delay));
    });

    $(document).on('click', '.b-block_equipment-controls__item_right', function(event){
        var next_item = ($('.b-block_equipment__item_active').next().length > 0 ? $('.b-block_equipment__item_active').next() : $('.b-block_equipment__item:first'));

        $('.b-block_equipment__item_active').removeClass('b-block_equipment__item_active');
        $(next_item).addClass('b-block_equipment__item_active');

        $('.b-block_equipment-mini__item_active').removeClass('b-block_equipment-mini__item_active');
        $('.b-block_equipment-mini__item_' + $(next_item).attr('data-id')).addClass('b-block_equipment-mini__item_active');

        if ($('.b-block_equipment-mini__item:last').hasClass('b-block_equipment-mini__item_hidden') && $('.b-block_equipment-mini__item_' + $(next_item).attr('data-id')).hasClass('b-block_equipment-mini__item_hidden'))
        {
            $('.b-block_equipment-mini__item_' + $(next_item).attr('data-id')).removeClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item:not(.b-block_equipment-mini__item_hidden):first').addClass('b-block_equipment-mini__item_hidden');
        }
        else
        {
            $('.b-block_equipment-mini__item').removeClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item_9').addClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item_10').addClass('b-block_equipment-mini__item_hidden');
            $('.b-block_equipment-mini__item_11').addClass('b-block_equipment-mini__item_hidden');
        }

        for(var i = 0, z = _equipment_timeouts.length; i < z; i++)
        {
            clearTimeout(_equipment_timeouts[i]);
        }

        _equipment_timeouts = [];

        _equipment_timeouts.push(setTimeout(function(){
            rotateEquipment();
        }, _equipment_delay));
    });

    $(document).on('click', '.b-block_equipment-mini__item', function(event){
        $('.b-block_equipment-mini__item_active').removeClass('b-block_equipment-mini__item_active');
        $(this).addClass('b-block_equipment-mini__item_active');

        $('.b-block_equipment__item_active').removeClass('b-block_equipment__item_active');
        $('.b-block_equipment__item_' + $(this).attr('data-id')).addClass('b-block_equipment__item_active');

        for(var i = 0, z = _equipment_timeouts.length; i < z; i++)
        {
            clearTimeout(_equipment_timeouts[i]);
        }

        _equipment_timeouts = [];

        _equipment_timeouts.push(setTimeout(function(){
            rotateEquipment();
        }, _equipment_delay));
    });

    function rotateEquipment()
    {
        if (!_equipment_mouseover)
        {
            $('.b-block_equipment-controls__item_right').click();
        }

        _equipment_timeouts.push(setTimeout(function(){
            rotateEquipment();
        }, _equipment_delay));
    }

    _equipment_timeouts.push(setTimeout(function(){
        rotateEquipment();
    }, _equipment_delay));
    /* \Equipment */


//==========EoF==============
	});
});