//webfont-load
WebFont.load({
    google: {
        families: ['Roboto:300,700:latin,cyrillic']
    },
    active: function() {
        console.log('fonts-active');
        initalize();
    }
});
console.log('fonts-start');



//initalize
function initalize() {

    console.log('inited');

    //load_CSS function
    ! function(e) {
        "use strict"
        var n = function(n, t, o) {
            function i(e) {
                return f.body ? e() : void setTimeout(function() {
                    i(e)
                })
            }
            var d, r, a, l, f = e.document,
                s = f.createElement("link"),
                u = o || "all"
            return t ? d = t : (r = (f.body || f.getElementsByTagName("head")[0]).childNodes, d = r[r.length - 1]), a = f.styleSheets, s.rel = "stylesheet", s.href = n, s.media = "only x", i(function() {
                d.parentNode.insertBefore(s, t ? d : d.nextSibling)
            }), l = function(e) {
                for (var n = s.href, t = a.length; t--;)
                    if (a[t].href === n) return e()
                setTimeout(function() {
                    l(e)
                })
            }, s.addEventListener && s.addEventListener("load", function() {
                this.media = u
            }), s.onloadcssdefined = l, l(function() {
                s.media !== u && (s.media = u)
            }), s
        }
        "undefined" != typeof exports ? exports.loadCSS = n : e.loadCSS = n
    }("undefined" != typeof global ? global : this)

    // loadCSS("css/libs.min.css");
    // loadCSS("css/style.min.css");
    loadCSS("css/fonts.css");
    loadCSS("css/libs.min.css");
    loadCSS("css/style.css");
    //console.log('css-append');

    ! function(e, t, n) {
        function r() {
            for (; u[0] && "loaded" == u[0][l];) o = u.shift(), o[f] = !a.parentNode.insertBefore(o, a)
        }
        for (var i, s, o, u = [], a = e.scripts[0], f = "onreadystatechange", l = "readyState"; i = n.shift();) s = e.createElement(t), "async" in a ? (s.async = !1, e.head.appendChild(s)) : a[l] ? (u.push(s), s[f] = r) : e.write("<" + t + ' src="' + i + '" defer></' + t + ">"), s.src = i
    }(document, "script", [
        // "https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js",
        "js/libs.min.js",
        "js/main.js",
    ]);
    console.log('js-append');
    // hide-loader
    setTimeout(function() {
        document.getElementsByTagName('body')[0].className += ' pre-loaded';
    }, 1000);
    console.log('main-js.injected');

}



// initalize();